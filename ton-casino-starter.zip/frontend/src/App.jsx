import React from 'react'

const App = () => {
  return (
    <div style={{ backgroundColor: '#121212', color: 'white', height: '100vh', padding: '20px' }}>
      <h1>🎁 Открой бесплатный кейс</h1>
      <button style={{ padding: '10px 20px', marginTop: '20px' }}>Открыть</button>
      <hr />
      <h2>💰 Баланс: 0.1 TON</h2>
      <p>👤 Ник: @username</p>
      <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
        {[1, 3, 6, 10, 50, 100].map(price => (
          <div key={price} style={{ border: '1px solid white', padding: '10px', borderRadius: '8px' }}>
            Кейс — {price} TON
          </div>
        ))}
      </div>
      <div style={{ position: 'fixed', bottom: '20px', left: 0, right: 0, display: 'flex', justifyContent: 'space-around' }}>
        <button>📦</button>
        <button>🎡</button>
        <button>👥</button>
        <button>💸</button>
      </div>
    </div>
  )
}

export default App