import React from 'react'

export default function NavBar() {
  return (
    <nav className="navbar">
      <button>📦</button>
      <button>🎯</button>
      <button>👥</button>
      <button>💸</button>
    </nav>
  )
}
