import React from 'react'

const cases = [
  { price: 1 }, { price: 3 }, { price: 6 },
  { price: 10 }, { price: 50 }, { price: 100 }
]

export default function CaseGrid() {
  return (
    <div className="case-grid">
      {cases.map((c, i) => (
        <div className="case" key={i}>
          <img src={`/assets/case${i+1}.png`} alt={`Case ${i+1}`} />
          <div>{c.price} TON</div>
        </div>
      ))}
    </div>
  )
}
