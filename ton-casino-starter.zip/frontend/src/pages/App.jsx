import React from 'react'
import CaseGrid from '../components/CaseGrid'
import NavBar from '../components/NavBar'

export default function App() {
  return (
    <div className="app-container">
      <header className="header">
        <div className="balance">💰 0.1 TON</div>
        <div className="username">@username</div>
      </header>

      <main>
        <div className="free-case">
          <button className="open-free">Открыть бесплатный кейс</button>
        </div>
        <CaseGrid />
      </main>

      <NavBar />
    </div>
  )
}
